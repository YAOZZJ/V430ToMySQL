using GalaSoft.MvvmLight;

namespace V430ToMySQL.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel()
        {
        }
    }
}